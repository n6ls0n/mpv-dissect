int mpv_main(int argc, char *argv[]);
